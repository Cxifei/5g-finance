//app.js
App({
  onLaunch: function () { 
    // 1. 获取系统信息
    // 获取头部导航条的高度，因为在不同的手机型号头部状态栏高度可能不一致。
    wx.getSystemInfo({
      success: (res) => {
        // 导航高度
        this.globalData.navHeight = res.statusBarHeight + 46;
        this.globalData.contenteight = res.windowHeight - (res.statusBarHeight + 46)
      }
    })
  },
   /**
     * 设置监听器
     */
  setWatcher(data, watch,that) { // 接收index.js传过来的data对象和watch对象
    Object.keys(watch).forEach(v => { // 将watch对象内的key遍历
        this.observe(data, v,watch[v],that); // 监听data内的v属性，传入watch内对应函数以调用
    })
  },
  /**
   * 监听属性 并执行监听函数 修改默认推荐
   */
  observe(obj, key,watchFun,that) {
      var val = obj[key]; // 给该属性设默认值
      Object.defineProperty(obj, key, {
          configurable: true,
          enumerable: true,
          set: function(value) {
              val = value;
              watchFun(value,val); // 赋值(set)时，调用对应函数
          },
          get: function() {
              return val;
          }
      })
  },
  globalData: {
    // 
    HotProduct:null,
    navHeight:0,
    contenteight:0,
    navtext:null,
    //用户数据
    userInfos:null,
    city:null,
    token:null,
    Url:'http://47.106.241.195',
    doc:null
  }
})