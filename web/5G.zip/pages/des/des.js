// pages/des/des.js
const app = getApp().globalData
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:getApp().globalData.navHeight,
    user:null,
    doc:null,
    // 估值
    guzhi:'估值',
    // 负债率
    fuzhailv:'负债率',
    // 周期
    zhouqi:'周期',
    // 批复
    pifu:'批复',
    // 到期
    daoqi:'到期',
    // 面积
    mianji:null,
    // 楼面价
    loumianjia:null,
    // 容积率
    rongjilv:null,
    // 房价
    fangjia:null,
    // 征信
    zhengxin:'征信',
    // 抵押物
    diyawu:'抵押物',
    // 类型
    leixing:'类型',
    // 风控
    fengkong:'风控',
    // 出款
    chukuan:'出款'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      title:getApp().globalData.navtext
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log(app.doc)
    this.setData({
      doc:app.doc,
      user:getApp().globalData.userInfos
    })
    switch (app.doc.type) {
      case '过桥':{
      }break;
      case '个贷':{
        this.setData({
          fuzhailv:'折率',
          pifu:null,
          leixing:'出款',
        })
      }break;
      case '企贷':{
        this.setData({
          fuzhailv:null,
          pifu:'用途',
          leixing:'出款'
        })
      }break;
      case '国企':{
        this.setData({
          fuzhailv:'负债率',
          pifu:'用途',
          leixing:'出款'
        })
      }break;
      case '房地产':{
        this.setData({
          fuzhailv:'利润率',
          pifu:'用途',
          mianji:'面积',
          loumianjia:'楼面价',
          rongjilv:'容积率',
          fangjia:'房价',
          zhengxin:'取得',
          chukuan:'类型',
          daoqi:null
        })
      }break;
      case '摆账':{
        this.setData({
          guzhi:null,
          fuzhailv:null,
          pifu:'用途',
          diyawu:null,
          chukuan:'类型',
          daoqi:null,
        })
      }break;
      case '票据':{
        this.setData({
          guzhi:'票面',
          fuzhailv:null,
          zhouqi:'背书',
          pifu:null,
          zhengxin:'状态',
          diyawu:null,
          fengkong:'利息',
          chukuan:'类型'
        })
      }break;
      case '上市公司':{
        this.setData({
          pifu:'用途',
          chukuan:'类型',
          fuzhailv:'折率'
        })
      }break;
    }
    this.setData({
      doc:app.doc
    })
    // console.log(app.doc)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  backClick:function(){
    // 在C页面内 navigateBack，将返回A页面
    wx.navigateBack({
      delta: 1
    })
  },
  // 拨打电话
  CallClick:function(){
    wx.makePhoneCall({
      phoneNumber: '18284140030' //仅为示例，并非真实的电话号码
    })
  },
  // 接单
  BuyOrderClick:function(){
    wx.showLoading({
      title: '加载中...',
      mask: true,
    });
      
    wx.request({
      url:getApp().globalData.Url + '/acceptBill',
      method:'POST',
      header:{
        'content-type':'application/x-www-form-urlencoded',
        'token':getApp().globalData.token
      },
      data:this.data.doc,
      success: function(res) {
        if(res.data.code == 200){
          wx.hideLoading();
          wx.showToast({
            title: '接单成功',
            icon: 'success'
          })
        }
        else{
          wx.hideLoading();
          wx.showToast({
            title: '接单失败',
            image:'../../assets/img/cuowu-3@2x.png'
          })
        }
      }
    })
  }
})