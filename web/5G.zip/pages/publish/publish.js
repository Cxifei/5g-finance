// pages/publish/publish.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    navH:getApp().globalData.navHeight,
    contentH:getApp().globalData.contenteight,
    typearray:['过桥','个贷','企贷','票据','摆账','上市公司','国企','房地产'],
    PersonalIsType:['土地','厂房','房产','车子','设备','信用'],
    BridgeIsTrue:true,
    PersonalIsTrue:false,
    CompaniesIsTrue:false,
    BillIsTrue:false,
    PendulumIsTrue:false,
    Corporation:false,
    StateOwnedEnterpriseIsTrue:false,
    RealtyIsTrue:false,
    // 过桥类型
    Bridgetype:['个人','企业'],
    // 佣金
    Commissiontype:['无','面议'],
    // 批复类型
    Replytepe:['银行','信托','小贷','其他'],
    // 出款类型
    gomoneyType:['银行','小贷','其他'],
    // 征信情况
    Credittype:['正常','非正常'],
    // 用途
    Usetype:['周转','创业','装修','经营','其他'],
    // 摆账用途
    Pendtype:['摆帐','冲量','保函','联名卡','存款','验资','小票','亮资','投标'],
    // 上市公司用途
    ComUse:['周转','平滑','投资','经营','其它'],
    // 公司类型
    ComType:['股质','信贷','大宗','配资','私募','并购','定增','卖壳','风投','IPO','ABS'],
    //公司风控
    ComRisk:['资产抵押','股票质押','天使','信用','担保'],
    // 公司抵押物
    Comzyw:['股票','土地','厂房','房产','设备','信用'],
    // 过桥抵押物
    guoqiao:['土地','厂房','房产','车子','设备','信用'],
    // 摆账类型
    PendUse:['个人','对公'],
    // 摆账风控
    PendRisk:['资产抵押','股权质押','信用','担保','账户共管','不出账户'],
    // 过桥风控类型
    Risktype:['资产抵押','股权质押','信用','担保','账户共管'],
    // 个贷风控类型
    personalRisktype:['资产抵押','股权质押','信用','担保'],
    // 票据利息
    lx:['前置','后置'],
    // 票据类型
    billType:['银票','商票'],
    // 国企出款
    stateparagraph:['银行','券商','信托','租赁','保险','机构','国企','基金'],
    // 国企风控
    statePen:['发债','PPN','土地抵押','资产抵押','股权质押','信用','平台担保'],
    // 国企抵押物
    stateRisk:['土地','厂房','设备','医院','信用'],
    // 个贷
    gedaiRisk:['土地','厂房','房产','车子','设备','信用'],
    // 房地产类型
    homeType:['开发贷','土地前融','变性款','并购','转让','合作开发','保证金','预售房','烂尾'],
    //房地产抵押物
    homeRisk:['住宅地','商业','工业','股权','预售房','房产','信用'],
    // 房地产用途
    homeUse:['周转','报建','工程款','装修','经营','其它'],
    // 房地产风控
    homePen:['土地抵押','股权质押','预售房抵押','公章共管','信用','担保'],
    Province:null,
    select:false,
    tihuoWay:"选择省...",
    thiscity:"选择市...",
    cityselect:false,
    City:null,
    // 表单类型(选择)
    formtype:String,
    // 发布人姓名(填写)
    name:String,
    // 金额(填写)
    money:Number,
    // 联系方式(填写)
    phone:Number,
    //类型(选择)
    type:String,
    //批复(选择)
    reply:String,
    // 地区(选择)
    site:String,
    //风控(选择)
    pneumatic:String,
    //佣金(选择)
    brokerage:String,
    //到期(填写)
    expire:Number,
    //估值(填写)
    cost:Number,
    //利率(填写)
    rate:Number,
    //周期(选择)
    period:String,
    //征信(选择)
    credit:String,
    //备注(填写)
    remark:String,
    // 负债率(填写)
    ratio:Number,
    // 用途
    use:String,
    // 抵押物
    ComDyw:String,
    // 面积
    area:Number,
    // 容积率
    plotratio:Number,
    // 楼面价
    accommodation:Number,
    // 房价
    homePrice:Number,
    //发单时间
    setOrder:Date,
    // 利息
    risk:String,
    // 发布状态
    is:Boolean,
    // 
    beishu:Boolean
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.GetNowTime()
    let cityData = require("../../assets/data/city");
    let ProvinceArray = []
    cityData.City.provinces.forEach(item => {
      ProvinceArray.push(item.provinceName)
    })
    this.setData({
      Province:ProvinceArray
    })
  },
  
  onShow:function(e){
    // 认证提醒
    if(getApp().globalData.userInfos){
      if(getApp().globalData.userInfos.validation == 0){
        wx.showModal({
          title: '提示',
          content: '你还未实名认证，部分功能将无法体验，是否前往认证？',
          success (res) {
            if (res.confirm) {
              wx.navigateTo({
                url:'../../pages/identification/identification'
              })
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      }
    }
   if(!getApp().globalData.userInfos){
    
   }
   else{
    this.setData({
      name:getApp().globalData.userInfos.name,
      phone:getApp().globalData.userInfos.phone
    })
    if(getApp().globalData.userInfos.validation){
      this.setData({
        is:true
      })
    }
    else{
      this.setData({
        is:true
      })
    }
   }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },
  //提交表单生成发布表单
  formSubmit: function(e) {
    if(!getApp().globalData.userInfos){
      wx.navigateTo({
        url: '../../pages/login/login'
      })
      return
    }
    if(getApp().globalData.userInfos.validation == 0){
      wx.showToast({
        title:'请前往认证',
        image:'../../assets/img/cuowu-3@2x.png',
        mask:true
      })
      return
    }
    let ratio = e.detail.value.ratio ? e.detail.value.ratio : null;
    let cost = e.detail.value.cost ? e.detail.value.cost : null;
    let expire = e.detail.value.expireTime ? e.detail.value.expireTime : null;
    let accommodation = e.detail.value.price ? e.detail.value.price : null;
    let area = e.detail.value.area ? e.detail.value.area :null;
    let site = this.data.thiscity
    let plotratio = e.detail.value.plotratio ? e.detail.value.plotratio : null;
    let homePrice = e.detail.value.homeprice ? e.detail.value.homeprice : null
    let beish = e.detail.value.beishu ? e.detail.value.beishu : null
    this.setData({
      cost:cost,
      money:e.detail.value.money,
      name:e.detail.value.name,
      phone:e.detail.value.phone,
      expire:expire,
      rate:e.detail.value.rate,
      credit:e.detail.value.creditRadio,
      period:e.detail.value.period + e.detail.value.periodRadio,
      beishu:e.detail.value.beishu,
      site:site,
      remark:e.detail.value.textarea,
      ratio:ratio,
      area:area,
      plotratio:plotratio,
      accommodation:accommodation,
      homePrice:homePrice,
      beishu:beish
    })
    let msg = this.data
    switch (this.data.formtype) {
      case '过桥':{
         let bridge ={
          // 表单类型(选择)
          type:msg.formtype,
          // 抵押物
          mortqaqed:msg.ComDyw,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          //批复(选择)
          reply:msg.reply,
          // 地区(选择)
          address:msg.site,
          //风控(选择)
          risk:msg.pneumatic,
          //佣金(选择)
          commossion:msg.brokerage,
          //到期(填写)
          editor:msg.expire,
          //估值(填写)
          valuation:msg.cost,
          //利率(填写)
          rate:msg.rate,
          //周期(选择)
          cycle:msg.period,
          //征信(选择)
          creditplus:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          // 负债率
          levorprofit:msg.ratio,
          //发单时间
          setOrder:msg.setOrder
         }
         this.setOrder(bridge)
         this.ForObiect(bridge)
      }break;
      case '个贷':{
        let bridge ={
          //发单时间
          setOrder:msg.setOrder,
          //个贷
          mortqaqed:msg.ComDyw,
          // 表单类型(选择)
          type:msg.formtype,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          // 地区(选择)
          address:msg.site,
          //风控(选择)
          risk:msg.pneumatic,
          //佣金(选择)
          commossion:msg.brokerage,
          //到期(填写)
          editor:msg.expire,
          //估值(填写)
          valuation:msg.cost,
          //利率(填写)
          rate:msg.rate,
          //周期(选择)
          cycle:msg.period,
          //征信(选择)
          creditplus:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          // 负债率
          levorprofit:msg.ratio,
          //用途
          used:msg.use
        }
        this.setOrder(bridge)
      }break;
      case '企贷':{
        let bridge ={
          //发单时间
          setOrder:msg.setOrder,
          //个贷
          mortqaqed:msg.ComDyw,
          // 表单类型(选择)
          type:msg.formtype,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          // 地区(选择)
          address:msg.site,
          //风控(选择)
          risk:msg.pneumatic,
          //佣金(选择)
          commossion:msg.brokerage,
          //到期(填写)
          editor:msg.expire,
          //估值(填写)
          valuation:msg.cost,
          //利率(填写)
          rate:msg.rate,
          //周期(选择)
          cycle:msg.period,
          //征信(选择)
          creditplus:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          //用途
          used:msg.use
        }
        this.setOrder(bridge)
      }break;
      case '票据':{
        let bridge ={
          //发单时间
          setOrder:msg.setOrder,
          //票面(填写)
          valuation:msg.cost,
          //背书(选择)
          cycle:msg.beishu,
          // 表单类型(选择)
          type:msg.formtype,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          // 地区(选择)
          address:msg.site,
          //佣金(选择)
          commossion:msg.brokerage,
          //到期(填写)
          editor:msg.expire,
          //利率(填写)
          rate:msg.rate,
          //状态(选择)
          creditplus:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          // 利息
          risk:msg.risk
        }
        this.setOrder(bridge)
        console.log(bridge)
      }break;
      case '摆账':{
        let bridge ={
          //发单时间
          setOrder:msg.setOrder,
          // 表单类型(选择)
          type:msg.formtype,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          // 地区(选择)
          address:msg.site,
          //佣金(选择)
          commossion:msg.brokerage,
          //利率(填写)
          rate:msg.rate,
          //周期(选择)
          cycle:msg.period,
          //状态(选择)
          credit:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          // 用途
          used:msg.use,
          // 征信
          creditplus:msg.credit,
          // 风控
          risk:msg.pneumatic
        }
        this.setOrder(bridge)
        console.log(bridge)
      }break;
      case '上市公司':{
        let bridge ={
          //发单时间
          setOrder:msg.setOrder,
          // 表单类型(选择)
          type:msg.formtype,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          //用途(选择)
          used:msg.use,
          // 地区(选择)
          address:msg.site,
          //风控(选择)
          risk:msg.pneumatic,
          //佣金(选择)
          commossion:msg.brokerage,
          //到期(填写)
          editor:msg.expire,
          //估值(填写)
          valuation:msg.cost,
          //利率(填写)
          rate:msg.rate,
          //周期(选择)
          cycle:msg.period,
          //征信(选择)
          creditplus:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          // 负债率
          levorprofit:msg.ratio,
          // 抵押物
          mortqaqed:msg.ComDyw
        }
        this.setOrder(bridge)
        console.log(bridge)
      }break;
      case '国企':{
        let bridge ={
          //发单时间
          setOrder:msg.setOrder,
          // 表单类型(选择)
          type:msg.formtype,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          //用途(选择)
          used:msg.use,
          // 地区(选择)
          address:msg.site,
          //风控(选择)
          risk:msg.pneumatic,
          //佣金(选择)
          commossion:msg.brokerage,
          //到期(填写)
          editor:msg.expire,
          //估值(填写)
          valuation:msg.cost,
          //利率(填写)
          rate:msg.rate,
          //周期(选择)
          cycle:msg.period,
          //征信(选择)
          creditplus:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          // 负债率
          levorprofit:msg.ratio,
          // 抵押物
          mortqaqed:msg.ComDyw
        }
        this.setOrder(bridge)
        console.log(bridge)
      }break;
      case '房地产':{
        let bridge ={
          //发单时间
          setOrder:msg.setOrder,
          // 表单类型(选择)
          type:msg.formtype,
          // 金额(填写)
          amount:msg.money,
          //类型(选择)
          prototypes:msg.type,
          //用途(选择)
          used:msg.use,
          // 地区(选择)
          address:msg.site,
          //风控(选择)
          risk:msg.pneumatic,
          //佣金(选择)
          commossion:msg.brokerage,
          //估值(填写)
          valuation:msg.cost,
          //利率(填写)
          rate:msg.rate,
          //周期(选择)
          cycle:msg.period,
          //征信(选择)
          creditplus:msg.credit,
          //备注(填写)
          instructions:msg.remark,
          // 利润率
          levorprofit:msg.ratio,
          // 抵押物
          mortqaqed:msg.ComDyw,
          // 面积
          area:msg.area,
          plot:msg.plotratio,
          floorprice:msg.accommodation,
          houseprice:msg.homePrice
        }
        this.setOrder(bridge)
        console.log(bridge)
      }break;
    }
  },
  bindChange: function(e) {
    let val = e.detail.value
    this.setData({
      seltype:val[0]
    })
  },
  bindKeyInput:function (e) {
    switch (e.currentTarget.id) {
      case "time":{}break;
      case "rate":{}break;
      case "cost":{}break;
      case "expire":{}break;
      case "phone":{}break;
      case "money":{}break;
      case "name":{}break;
    }
  },
   // 下拉框
   bindShowMsg() {
    let showcity = this.data.select == true ? false : true
    this.setData({
        select:showcity
    })
  },
  //选择省份
  mySelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
        tihuoWay: name,
        select: false
    })
    let cityData = require("../../assets/data/city");
    let CityArray = [];
    cityData.City.provinces.forEach(item => {
      if(item.provinceName == this.data.tihuoWay){
        item.citys.forEach(des =>{
          CityArray.push(des.citysName)
        })
      }
    })
    this.setData({
      City:CityArray,
      thiscity:'选择市...'
    })
  },
  // 显示城市
  bindShowCity(){
    if(this.data.City){
      let showcity = this.data.cityselect == true ? false : true
      this.setData({
        cityselect:showcity
      })
    }
  },
  // 选择城市
  mySelectcity(e){
    let name = e.currentTarget.dataset.name
    this.setData({
        thiscity: name,
        cityselect: false
    })
    this.triggerEvent('myevent', {name});
  },
  // 选择类型
  selvalue:function(e){
    switch (e.detail.name) {
      case '过桥':{
        this.setData({
          formtype:'过桥'
        })
        this.sel(1)
      }break;
      case '个贷':{
        this.setData({
          formtype:'个贷'
        })
        this.sel(2)
      }break;
      case '企贷':{
        this.setData({
          formtype:'企贷'
        })
        this.sel(3)
      }break;
      case '票据':{
        this.setData({
          formtype:'票据'
        })
        this.sel(4)
      }break;
      case '摆账':{
        this.setData({
          formtype:'摆账'
        })
        this.sel(5)
      }break;
      case '上市公司':{
        this.setData({
          formtype:'上市公司'
        })
        this.sel(6)
      }break;
      case '国企':{
        this.setData({
          formtype:'国企'
        })
        this.sel(7)
      }break;
      case '房地产':{
        this.setData({
          formtype:'房地产'
        })
        this.sel(8)
      }break;
    }
    // 获取表单参数
    switch (e.detail.sel) {
      case '类型':{
        this.setData({
          type:e.detail.name
        })
      }break;
      case '出款':{
        this.setData({
          type:e.detail.name
        })
      }break;
      case '批复':{
        this.setData({
          reply:e.detail.name
        })
      }break;
      case '地区':{
        this.setData({
          site:e.detail.name
        })
      }break;
      case '风控':{
        this.setData({
          pneumatic:e.detail.name
        })
      }break;
      case '佣金':{
        this.setData({
          brokerage:e.detail.name
        })
      }break;
      case '用途':{
        this.setData({
          use:e.detail.name
        })
      }break;
      case '抵押物':{
        this.setData({
          ComDyw:e.detail.name
        })
      }break;
      case '利息':{
        this.setData({
          risk:e.detail.name
        })
      }break;
    }
  },
  //选择发布类型
  sel:function (idx) {
    switch (idx) {
      case 1:{
        this.setData({
          BridgeIsTrue:true,
          PersonalIsTrue:false,
          CompaniesIsTrue:false,
          BillIsTrue:false,
          PendulumIsTrue:false,
          Corporation:false,
          StateOwnedEnterpriseIsTrue:false,
          RealtyIsTrue:false
        })
        this.rest()
      }break;
      case 2:{
        this.setData({
          BridgeIsTrue:false,
          PersonalIsTrue:true,
          CompaniesIsTrue:false,
          BillIsTrue:false,
          PendulumIsTrue:false,
          Corporation:false,
          StateOwnedEnterpriseIsTrue:false,
          RealtyIsTrue:false
        })
        this.rest()
      }break;
      case 3:{
        this.setData({
          BridgeIsTrue:false,
          PersonalIsTrue:false,
          CompaniesIsTrue:true,
          BillIsTrue:false,
          PendulumIsTrue:false,
          Corporation:false,
          StateOwnedEnterpriseIsTrue:false,
          RealtyIsTrue:false
        })
        this.rest()
      }break;
      case 4:{
        this.setData({
          BridgeIsTrue:false,
          PersonalIsTrue:false,
          CompaniesIsTrue:false,
          BillIsTrue:true,
          PendulumIsTrue:false,
          Corporation:false,
          StateOwnedEnterpriseIsTrue:false,
          RealtyIsTrue:false
        })
        this.rest()
      }break;
      case 5:{
        this.setData({
          BridgeIsTrue:false,
          PersonalIsTrue:false,
          CompaniesIsTrue:false,
          BillIsTrue:false,
          PendulumIsTrue:true,
          Corporation:false,
          StateOwnedEnterpriseIsTrue:false,
          RealtyIsTrue:false
        })
        this.rest()
      }break;
      case 6:{
        this.setData({
          BridgeIsTrue:false,
          PersonalIsTrue:false,
          CompaniesIsTrue:false,
          BillIsTrue:false,
          PendulumIsTrue:false,
          Corporation:true,
          StateOwnedEnterpriseIsTrue:false,
          RealtyIsTrue:false
        })
        this.rest()
      }break;
      case 7:{
        this.setData({
          BridgeIsTrue:false,
          PersonalIsTrue:false,
          CompaniesIsTrue:false,
          BillIsTrue:false,
          PendulumIsTrue:false,
          Corporation:false,
          StateOwnedEnterpriseIsTrue:true,
          RealtyIsTrue:false
        })
        this.rest()
      }break;
      case 8:{
        this.setData({
          BridgeIsTrue:false,
          PersonalIsTrue:false,
          CompaniesIsTrue:false,
          BillIsTrue:false,
          PendulumIsTrue:false,
          Corporation:false,
          StateOwnedEnterpriseIsTrue:false,
          RealtyIsTrue:true
        })
        this.rest()
      }break;
    }
  },
  // 单选
  radioChange:function (e) {
    console.log(e)
  },
  // 备注
  bindTextAreaBlur:function(e){
    console.log(e)
  },
  // 获取当前时间
  GetNowTime:function(e){
    var date = new Date();
    var seperator1 = "-";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
    this.setData({
      setOrder:currentdate
    })
  },
  // 提交表单
  setOrder:function(order){
    console.log(order)
    let index = 1
    for(let item in order){
      if(order[item] == '' || order[item] === String || order[item] == null || order[item] == '选择市...'){
        index = -1;
      }
    }
    if(index != 1){
      wx.showToast({
        title:'请完善信息',
        image:'../../assets/img/cuowu-3@2x.png',
        mask:true
      })
      console.log(order)
      return
    }
    wx.showLoading({
      title: '发布中',
      mask: true
    });
    wx.request({
      url:getApp().globalData.Url + '/addBill',
      header:{
        'content-type':'application/x-www-form-urlencoded',
        'token':getApp().globalData.token
      },
      method:'POST',
      data:order,
      success: function(des) {
        if(des.data.code == 200){
          wx.hideLoading();
          wx.showToast({
            title: '发布成功,等待审核', 
            icon: 'success'
          })
        }
        else{
          wx.hideLoading();
          wx.showToast({
            title: des.data.msg,
            image:'../../assets/img/cuowu-3@2x.png'
          })
        }
      }
    })
  },
  // 循环对象
  ForObiect:function(Objiex){
    let index = 1
    for (let index in Objiex){
      if(Objiex[index] == null || Objiex[index] == '选择市...'){
        index = -1
      }
    }
  },
  // 重置数据
  rest:function(){
    this.setData({
    // 金额(填写)
    money:Number,
    //类型(选择)
    type:String,
    //批复(选择)
    reply:String,
    // 地区(选择)
    site:String,
    //风控(选择)
    pneumatic:String,
    //佣金(选择)
    brokerage:String,
    //到期(填写)
    expire:Number,
    //估值(填写)
    cost:Number,
    //利率(填写)
    rate:Number,
    //周期(选择)
    period:String,
    //征信(选择)
    credit:String,
    //备注(填写)
    remark:String,
    // 负债率(填写)
    ratio:Number,
    // 用途
    use:String,
    // 抵押物
    ComDyw:String,
    // 面积
    area:Number,
    // 容积率
    plotratio:Number,
    // 楼面价
    accommodation:Number,
    // 房价
    homePrice:Number,
    //发单时间
    setOrder:Date,
    // 利息
    risk:String,
    // 发布状态
    is:Boolean,
    // 
    beishu:Boolean
    })
  }
})