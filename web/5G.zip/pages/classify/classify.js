// pages/classify/classify.js
const app = getApp().globalData 
const Url = app.Url
//请求字段
const GetUrl = getApp().globalData.Url + '/findBillListByType'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:getApp().globalData.navHeight,
    title:null,
    contentH:getApp().globalData.contenteight,
    array:['默认','时间','金额'],
    selIndex:0,
    Msg:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      title:getApp().globalData.navtext
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 分类请求数据
    switch (this.data.title) {
      case '过桥':{
        this.GetInfos(GetUrl,'GET',this,'过桥')
      }break;
      case '个贷':{
        this.GetInfos(GetUrl,'GET',this,'个贷')
      }break;
      case '企贷':{
        this.GetInfos(GetUrl,'GET',this,'企贷')
      }break;
      case '上市公司':{
        this.GetInfos(GetUrl,'GET',this,'上市公司')
      }break;
      case '房地产':{
        this.GetInfos(GetUrl,'GET',this,'房地产')
      }break;
      case '摆账':{
        this.GetInfos(GetUrl,'GET',this,'摆账')
      }break;
      case '票据':{
        this.GetInfos(GetUrl,'GET',this,'票据')
      }break;
      case '国企':{
        this.GetInfos(GetUrl,'GET',this,'国企')
      }break;
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  backClick:function(){
    // 在C页面内 navigateBack，将返回A页面
    wx.navigateBack({
      delta: 1
    })
  },
  // 跳转详情页
  godesClick:function(e){
    if(!getApp().globalData.userInfos){
      wx.navigateTo({
        url: '../../pages/login/login'
      })
      return
    }
    if(getApp().globalData.userInfos.validation == 0){
      wx.showToast({
        title:'请前往认证',
        image:'../../assets/img/cuowu-3@2x.png',
        mask:true
      })
      return
    }
    app.doc = this.data.Msg[e.currentTarget.dataset.index]
    wx.navigateTo({
      url: '../../pages/des/des'
    })
  },
  //请求数据
  GetInfos:function(url,type,that,MsgType){
    wx.request({
      url:url,
      method:type,
      header:{
        'content-type':'application/json'
      },
      data:{
        type:MsgType
      },
      success(res){
        if(res.data.code == 200){
          console.log(res.data.data)
          that.setData({
            Msg:res.data.data
          })
        }
        else{
          that.setData({
            Msg:[]
          })
        }
      }
    })
  },
  //过滤按钮
  filterClick:function(e){
    this.setData({
      selIndex:e.currentTarget.dataset.index
    })
    switch (this.data.selIndex) {
      case '0':{
        this.setData({
          Msg:this.data.Msg.sort((a, b) => b.id - a.id)
        })
      }break;
      case '1':{
        this.setData({
          Msg:this.data.Msg.sort((a, b) => b.createtime.localeCompare(a.createtime))
        })
      }break;
      case '2':{
        this.setData({
          Msg:this.data.Msg.sort((a, b) => b.amount - a.amount)
        })
      }break;
    }
  },
  // 子组件传值
  opationChange:function(e){
    
  }
})