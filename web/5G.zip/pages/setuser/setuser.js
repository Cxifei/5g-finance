// pages/setuser/setuser.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    touxiang:"../../assets/img/touxiang.png",
    User:null,
    city:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      User:getApp().globalData.userInfos,
      city:getApp().globalData.city
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 上传头像
  HeadImageUp:function(){
    let that = this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success (res) {
        // 处理图片
        wx.getFileSystemManager().readFile({
          filePath: res.tempFilePaths[0], //选择图片返回的相对路径
          encoding: 'base64', //编码格式
          success: res => { //成功的回调
            wx.showLoading({
              title: '修改中',
              mask:true
            })
            wx.request({
              url:getApp().globalData.Url + '/headUpload',
              method:'POST',
              header:{
                'content-type':'application/x-www-form-urlencoded',
                'token':getApp().globalData.token
              },
              data:{
                baseImg:'data:image/png;base64,' + res.data
              },
              success(des){
                if(des.data.code == 200){
                  setTimeout(function () {
                    wx.hideLoading()
                    if(des.data.code == 200){
                      that.setData({
                        User:des.data.data
                      })
                      getApp().globalData.userInfos = des.data.data
                    }else{
                      wx.showToast({
                        title:"修改失败",
                        image:'../../assets/img/cuowu-3@2x.png',
                        duration:1000
                      })
                    }
                  }, 2000)
                }
                else{
                  setTimeout(function () {
                      wx.showToast({
                        title:"修改失败",
                        image:'../../assets/img/cuowu-3@2x.png',
                        duration:1000
                      })
                  }, 2000)
                }
              }
            })
          }
        })
      }
    })
  },
  // 切换账号
  SwitchUser:function(){
    getApp().globalData.userInfos = null
    wx.navigateTo({
      url: '../login/login'
    });
    wx.setStorage({
      key:"token",
      data:null
    })
  },
  // 个性签名
  desChange:function(e){
    let a = e.detail.value
    let that = this
    wx.showLoading({
      title:'修改中',
      mask:true
    })
    wx.request({
      url:getApp().globalData.Url + '/changeUser',
      method:"POST",
      header:{
        'content-type':'application/x-www-form-urlencoded',
        'token':getApp().globalData.token
      },
      data:{
        msg:a
      },
      success(res){
        if(res.data.code == 200){
          setTimeout(function () {
            wx.hideLoading()
            wx.showToast({
              title:'修改成功',
              mask:true
            })
            that.setData({
              User:res.data.data
            })
            getApp().globalData.userInfos = res.data.data
          }, 2000)
        }
        else{
          setTimeout(function(){
            wx.showToast({
              title: '修改失败',
              icon: 'success',
              image:'../../assets/img/cuowu-3@2x.png',
              mask:true,
              duration: 1000
            })
          },1000)
         
        }
      }
    })
  }
})