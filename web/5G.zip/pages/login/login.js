// pages/login/login.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Istrue:true,
    SwitchText:'没有账号？去注册',
    // 账号验证
    IdIstrue:true,
    // 密码验证
    PwdIstrue:true,
    // 密码
    Pwd:null,
    // 再次输入密码验证
    AgainPwd:true,
    // 协议状态
    agreement:false,
    // 姓名状态
    nameIsTrue:true,
    // 验证码状态
    verification:true,
    // 验证码
    ver:null,
    // 账户
    id:null,
    // 密码显示状态
    pwdWitc:true,
    // 再次输入密码状态
    pwdWt:true,
    // 自动登录
    Login:false,
    max:10
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 登陆注册按钮
  LoginClick:function(e){
    let phoneq = this.data.id;
    let ver = this.data.ver
    let Msg = e.detail.value
    let t = this
    if(Msg.sex){
      wx.showLoading({
        title: '注册中',
        mask: true
      });
      if(!this.data.IdIstrue && !this.data.PwdIstrue && !this.data.AgainPwd && this.data.agreement && !this.data.nameIsTrue && !this.data.verification){
        wx.request({
          url:getApp().globalData.Url + '/validationCode',
          method:"POST",
          header:{'content-type': 'application/x-www-form-urlencoded'},
          data:{
            phone:phoneq,
            code:ver
          },
          success (des){
            if(des.data.code == 200){
              wx.request({
                url:getApp().globalData.Url + '/register',
                method:"POST",
                header:{'content-type': 'application/x-www-form-urlencoded'},
                data:(Msg),
                success(res){
                  if(res.data.code == 200){
                    wx.hideLoading();
                    wx.showToast({
                      title:'注册成功'
                    })
                    t.SwitchBtn()
                  }
                }
              })
            }
          }
        })
      }
    }
    // 登录
    else{
      if(!this.data.IdIstrue && !this.data.PwdIstrue){
        let that = this
        wx.request({
          url: getApp().globalData.Url + '/login', //仅为示例，并非真实的接口地址
          data: (Msg),
          method:'POST',
          header: {
            'content-type': 'application/x-www-form-urlencoded' // 默认值
          },
          success (res) {
            if(res.data.data){
              let token = res.data.data
              getApp().globalData.token = token
              wx.request({
                url: getApp().globalData.Url + '/showUser', 
                header: {
                  'content-type': 'application/json',
                  'token':token
                },
                success(d){
                  let user = {}
                  Object.assign(user,that.data.userInfos,d.data.data)
                  getApp().globalData.userInfos = user
                  wx.showLoading({
                    title: '登录中',
                    mask:true,
                  })
                  setTimeout(function () {
                    wx.hideLoading()
                    if(that.data.Login){
                      wx.setStorage({
                        key:"token",
                        data:token
                      })
                      wx.navigateBack({
                        delta: 2
                      })
                    }
                    else{
                      wx.navigateBack({
                        delta: 2
                      })
                    }
                  }, 2000)
                },
                fail: function() {
                  console.log('登录失败')
                }
              })
            }
            else{
              wx.showLoading({
                title: '登录中',
                mask:true
              })
              setTimeout(function () {
                wx.hideLoading()
                wx.showToast({
                  title: '登录失败',
                  image:'../../assets/img/cuowu-3@2x.png',
                  mask:true,
                  duration: 1000
                })
              }, 2000)
            }
          },
          fail: function() {
            console.log('登录失败')
          }
        })
        return
      }
    }
  },
  // 切换表单
  SwitchBtn:function(){
    let t = this.data.Istrue ? false : true;
    let text = this.data.SwitchText == '没有账号？去注册' ? '已有账号？去登录' : "没有账号？去注册"
    this.setData({
      Istrue:t,
      SwitchText:text,
      // 账号验证
      IdIstrue:true,
      // 密码验证
      PwdIstrue:true,
      // 密码显示状态
      pwdWitc:true,
      // 再次输入密码状态
      pwdWt:true,
      // 
      id:null
    })
  },
  // 重置
  reset:function(){

  },
  // 账号验证
  idClick:function(e){
    this.setData({
      id:e.detail.value
    })
    if(e.detail.value && (/^1[3456789]\d{9}$/.test(e.detail.value))){
      this.setData({
        IdIstrue:false
      })
    }
    else{
      this.setData({
        IdIstrue:true
      })
    }
  },
  // 密码验证
  PwdClick:function(e){
    console.log(/([a-zA-Z0-9!@#$%^&*()_?<>{}]){6,10}/.test(e.detail.value))
    if(e.detail.value && (/([a-zA-Z0-9!@#$%^&*()_?<>{}]){6,10}/.test(e.detail.value))){
      this.setData({
        PwdIstrue:false,
        Pwd:e.detail.value
      })
    }
    else{
      this.setData({
        PwdIstrue:true
      })
    }
  },
  // 再次输入验证
  AgainPwdClick:function (e) {
    if(this.data.Pwd == e.detail.value){
      this.setData({
        AgainPwd:false
      })
    }else{
      this.setData({
        AgainPwd:true
      })
    }
  },
  // 姓名输入状态
  nameClick:function(e){
    if(e.detail.value){
      this.setData({
        nameIsTrue:false
      })
    }
    else{
      this.setData({
        nameIsTrue:true
      })
    }
  },
  // 协议状态
  agreement:function(e){
    if(e.detail.value){
      this.setData({
        agreement:true
      })
    }
    else{
      this.setData({
        agreement:false
      })
    }
  },
  // 验证码
  verification:function(e){
    if(e.detail.value){
      this.setData({
        verification:false,
        ver:e.detail.value,
      })
    }
    else{
      this.setData({
        verification:true
      })
    }
  },
  // 请求验证码
  requstCode:function () {
    let that= this
    let po = this.data.id
    wx.request({
      url:getApp().globalData.Url + '/phoneCode',
      data:{
        phone:po
      },
      method:"POST",
      header:{'content-type': 'application/x-www-form-urlencoded'},
      success(des){
        if(des.data.code == 200){
          wx.showToast({
            title:'发送成功',
            mask:true
          })
          that.setData({
            IdIstrue:false
          })
        }
        else{
          that.setData({
            IdIstrue:true
          })
        }
      }
    })
  },
  // 清除账号
  clearId:function(){
    this.setData({
      id:null
    })
  },
  // 切换密码状态
  switchPwd:function(){
    let a = this.data.pwdWitc == true ? false : true
    this.setData({
      pwdWitc:a
    })
  },
  // 切换再次输入密码状态
  switchAgain:function(){
    let a = this.data.pwdW == true ? false : true
    this.setData({
      pwdW:a
    })
  },
  // 自动登录
  selfMotionLogin:function(e){
    if(e.detail.value){
      this.setData({
        Login:true
      })
    }
    else{
      this.setData({
        Login:false
      })
    }
  }
})