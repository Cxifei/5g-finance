//index.js
//获取应用实例
const app = getApp()
Page({
  data: {
    navH: getApp().globalData.navHeight,
    contentH:getApp().globalData.contenteight,
    currentCity: '定位中',
    check:false,
    hotcity:['北京','上海','成都','重庆'],
    allcity:[],
    // 推荐产品
    HotProduct:null,
  },
  onLoad: function () {
    let page = this
    //获取城市信息
    wx.getLocation({
      type: 'wgs84',   //默认为 wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标 
      success: function (res) {
        // success  
        let longitude = res.longitude
        let latitude = res.latitude
        page.loadCity(longitude,latitude)
      }
    })
    //设置监听器
    getApp().setWatcher(this.data,this.watch,page);
  },
  onShow:function(){
    // 自动登录
    if(!getApp().globalData.userInfos){
      wx.getStorage({
        key: 'token',
        success (res) {
          if(res.data){
            wx.request({
              url:getApp().globalData.Url + '/showUser',
              header:{
                'content-type':'application/json',
                'token':res.data
              },
              success(des){
                getApp().globalData.token = res.data
                getApp().globalData.userInfos = des.data.data
              }
            })
          }
        }
      })
    }
    let _this = this
    // 获取默认推荐
    wx.request({
      url:getApp().globalData.Url + '/findNewestBill',
      header:{
        'content-type':'application/json'
      },
      success: function(res) {
        if(res.data){
          _this.setData({
            HotProduct:res.data.data
          })
        }else{
          _this.setData({
            HotProduct:[]
          })
        }
        
      }
    })
  },
  //监听城市变化
  watch:{
    currentCity:function(value){
    }
  },
  //获取当前城市
  loadCity: function (longitude, latitude) {
    let page = this
    wx.request({
      url: 'https://api.map.baidu.com/geocoder/v2/?ak=DqRoZ5aVim34V7Ow5kMCtryVxYjWTGOi&location=' + latitude + ',' + longitude + '&output=json',
      data: {},
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        var city = res.data.result.addressComponent.city;
        getApp().globalData.city = city
        page.setData({ currentCity: city });
      },
      fail: function () {
        page.setData({ currentCity: "获取定位失败" });
      },
      
    })
  },
  //选择城市
  cityClick:function(){
    this.setData({
      check:true
    })
  },
  //修改城市
  changeCity:function(e){
    let {city} = e.target.dataset
    this.setData({
      currentCity:city
    })
  },
  //关闭城市选择
  offcheck:function(){
    this.setData({
      check:false
    })
  },
  // 分类按钮
  classifyClick:function(e){
    app.globalData.navtext = e.currentTarget.dataset.classify
    wx.navigateTo({
      url: '../classify/classify'
    })
  },
  //接收组件传值，并修改当前城市
  mySelectcity:function(e){
    this.setData({
      currentCity:e.detail.name
    })
  },
  // 跳转详情页
  goDesClick:function(e){
    if(!getApp().globalData.userInfos){
      wx.navigateTo({
        url: '../../pages/login/login'
      })
      return
    }
    if(getApp().globalData.userInfos.validation == 0){
      wx.showToast({
        title:'请前往认证',
        image:'../../assets/img/cuowu-3@2x.png',
        mask:true
      })
      return
    }
    getApp().globalData.doc = this.data.HotProduct[e.currentTarget.dataset.index]
    wx.navigateTo({
      url:'../../pages/des/des'
    })
  }
})
