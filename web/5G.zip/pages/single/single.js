// pages/single/single.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    single:[],
    // 订单状态
    IsTrue:null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getInfos()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //查看详情
  goDesClick:function(e){
    getApp().globalData.doc = this.data.single[e.currentTarget.dataset.index]
    wx.navigateTo({
      url: '../../pages/des/des'
    })
  },
  //删除
  delOrderClick:function(e){
    let _this = this
    if(e.currentTarget.dataset.name == '取消订单'){
      _this.delOrder(e)
    }
    else{
      if(this.data.single[e.currentTarget.dataset.index].uconfirm == 0){
        wx.showActionSheet({
          itemList: ['确认交易', '删除订单'],
          success (res) {
            if (res.tapIndex == 0) {
              wx.request({
                url:getApp().globalData.Url + '/issuerConfirm',
                method:'POST',
                header:{
                  'content-type':'application/x-www-form-urlencoded'
                },
                data:_this.data.single[e.currentTarget.dataset.index],
                success(des){
                  if(des.data.code == 301 || des.data.code){
                    wx.showToast({
                      title:des.data.msg,
                      mask:true
                    })
                    _this.getInfos()
                  }
                }
              })
            }else{
              _this.delOrder(e)
            }
          },
          fail (res) {
            console.log(res.errMsg)
          }
        })
      }
    }
  },
  // 取消交易
  SelOrder:function(e){
    let _this = this
    wx.request({
      url:getApp().globalData.Url + '/iCancellationOfTransactions',
      method:'POST',
      header:{
        'content-type':'application/x-www-form-urlencoded'
      },
      data:this.data.single[e.currentTarget.dataset.index],
      success(res){
        if(res.data.code == 200){
          wx.showModal({
            title: '提示',
            content: '是否取消交易？',
            success (res) {
              if (res.confirm) {
                _this.getInfos()
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      }
    })
  },
  // 请求数据
  getInfos:function(){
    let _this = this
    wx.request({
      url:getApp().globalData.Url + '/myInvoice',
      method:'GET',
      header:{
        'content-type':'application/json',
        'token':getApp().globalData.token
      },
      success: function(res) {
        _this.setData({
          single:res.data.data
        })
        console.log(res.data.data)
      }
    })
  },
  // 删除订单
  delOrder:function(e){
    let _this = this
    wx.request({
      url:getApp().globalData.Url + '/cancelBill',
      method:"POST",
      header:{
        'content-type':'application/x-www-form-urlencoded'
      },
      data:this.data.single[e.currentTarget.dataset.index],
      success(res){
        if(res.data.code == 200){
          wx.showToast({
            title:'删除成功',
            mask:true
          })
          _this.getInfos()
        }
        else{
          wx.showToast({
            title:'删除失败',
            mask:true,
            image:'../../assets/img/cuowu-3@2x.png'
          })
          this.setData({
            single:oldOrder
          })
        }
      }
    })
  }
})