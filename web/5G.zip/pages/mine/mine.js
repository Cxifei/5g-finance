const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    navH:getApp().globalData.navHeight,
    UserInfos:null,
    touxiang:"../../assets/img/touxiang.png"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if(getApp().globalData.userInfos){
      this.setData({
        UserInfos:getApp().globalData.userInfos,
        touxiang:'http://47.106.241.195:8888' + getApp().globalData.userInfos.head
      })
    }
    else{
      this.setData({
        UserInfos:null,
        touxiang:'../../assets/img/touxiang.png'
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 头像事件
  goLogin:function(){
    if(getApp().globalData.userInfos){
      wx.navigateTo({
        url: '../setuser/setuser'
      })
    }else{
      wx.navigateTo({
        url: '../login/login'
      })
    }
  },
  // 跳转订单页
  goorderClick:function(){
    if(!getApp().globalData.userInfos){
      wx.navigateTo({
        url: '../../pages/login/login'
      })
      return
    }
    wx.navigateTo({
      url:'../order/order'
    })
  },
  // 跳转甩单页
  gosingleClick:function(){
    if(!getApp().globalData.userInfos){
      wx.navigateTo({
        url: '../../pages/login/login'
      })
      return
    }
    wx.navigateTo({
      url:'../single/single'
    })
  },
  // 钱包
  moneyClick:function(){
    wx.showToast({
      title: '敬请期待',
      icon: 'success',
      mask:true,
      duration: 1000
    })
  },
  // 个人认证
  PACClick:function(){
    if(!getApp().globalData.userInfos){
      wx.navigateTo({
        url: '../../pages/login/login'
      })
      return
    }
    if(this.data.UserInfos.validation == 1){
      wx.showToast({
        title:'已验证',
        mask:true
      })
      return
    }else{
      wx.navigateTo({
        url:'../identification/identification'
      })
    }
  }
})