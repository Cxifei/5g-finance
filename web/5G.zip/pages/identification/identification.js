// pages/identification/identification.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    IdTop:'../../assets/img/Idcard.png',
    IdBot:'../../assets/img/Idcard.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // wx.request({
    //   url:'www.feteys.cn:8888',
    //   method:'GET',
    //   success(res){
    //     console.log(res)
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 正面照
  IdTopClick:function(){
    this.UpReadFile()
  },
  // 反面照
  IdBotClick:function(){
    // this.UpReadFile()
  },
  // 图片
  UpReadFile:function(){
    wx.chooseImage({
      count: 1,
      sizeType: ['original'],
      sourceType: ['album', 'camera'],
      success (res) {
        wx.showLoading({
          title: '上传中',
          mask:true
        })
        // 处理图片
        wx.getFileSystemManager().readFile({
          filePath: res.tempFilePaths[0], //选择图片返回的相对路径
          encoding: 'base64', //编码格式
          success: res => { //成功的回调
            if(res.data.length > 2048){
              wx.showToast({
                title:'图片较大,上传失败',
                image:'../../assets/img/cuowu-3@2x.png',
                mask:true
              })
              return
            }
            wx.request({
              url:getApp().globalData.Url + '/validationIdCard',
              method:'POST',
              header:{
                'content-type':'application/json',
                'token':getApp().globalData.token
              },
              data:res.data,
              success(des){
                getApp().globalData.userInfos = des.data.data
                setTimeout(function () {
                  wx.hideLoading()
                  if(des.data.code == 200){
                    wx.showToast({
                      title: '认证成功',
                      icon:'success'
                    })
                  }else{
                    wx.showToast({
                      title:'认证失败',
                      image:'../../assets/img/cuowu-3@2x.png'
                    })
                  }
                }, 2000)
                  
              }
            })
          }
        })
      }
    })
  }
})