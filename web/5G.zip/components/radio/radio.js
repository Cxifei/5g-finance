Component({
  properties:{
    opations:Array //选择项
  },
  data:{
    curIndex:0
  },
  methods: {
    itemClick(event){
      let {opation,index} = event.target.dataset;
      this.setData({
        curIndex:index
      })
      this.triggerEvent('opationChange',opation)
    }
  },
})