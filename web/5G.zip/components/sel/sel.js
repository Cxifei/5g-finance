// components/sel/sel.js
Component({
  /**
   * 页面的初始数据
   */
  properties: {
    type:Array,
    sel:String,
  },
  data: {
    seltype:'',
    selTypeIs:false
  },
  attached:function (params) {
  },
  methods: {
    // 
    bindShowMsg:function(){
      let istrue = this.data.selTypeIs ? false : true
      this.setData({
        selTypeIs:istrue
      })
    },
    // 选择发布类型
    mySelect:function(e){
      this.setData({
        selTypeIs:false,
        seltype:e.currentTarget.dataset.name
      })
      let name = e.currentTarget.dataset.name
      let sel = this.properties.sel
      this.triggerEvent('selvalue', {sel,name});
    }
  },
})