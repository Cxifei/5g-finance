const app = getApp();

  
Component({
  properties: {
    options: Array // 选择项
  },
  data: {
    Province:null,
    select:false,
    tihuoWay:"请选择省份...",
    thiscity:"请选择市...",
    cityselect:false,
    City:null
  },
  attached: function() {
    let cityData = require("../../assets/data/city");
    let ProvinceArray = []
    cityData.City.provinces.forEach(item => {
      ProvinceArray.push(item.provinceName)
    })
    this.setData({
      Province:ProvinceArray
  })
  },
  detached: function() {
    // 在组件实例被从页面节点树移除时执行
  },
  methods: {
    // 下拉框
    bindShowMsg() {
      this.setData({
          select:!this.data.select
      })
    },
    //选择省份
    mySelect(e) {
      var name = e.currentTarget.dataset.name
      this.setData({
          tihuoWay: name,
          select: false
      })
      let cityData = require("../../assets/data/city");
      let CityArray = [];
      cityData.City.provinces.forEach(item => {
        if(item.provinceName == this.data.tihuoWay){
          item.citys.forEach(des =>{
            CityArray.push(des.citysName)
          })
        }
      })
      this.setData({
        City:CityArray
      })
    },
    // 显示城市
    bindShowCity(){
      this.setData({
        cityselect:!this.data.cityselect
      })
    },
    // 选择城市
    mySelectcity(e){
      let name = e.currentTarget.dataset.name
      this.setData({
          thiscity: name,
          cityselect: false
      })
      this.triggerEvent('myevent', {name});
    }
  },
});
